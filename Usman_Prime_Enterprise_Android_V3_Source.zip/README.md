# Usman Prime Enterprise — Android V3 source project

This is an Android Studio project source, not an APK.

Open the folder in Android Studio and build an APK. It contains the V3 mobile interface and the Paystack TEST public key.

Important: the payment screen is still a test/prototype. Do not put a Paystack secret key in the app. Production payments require a secure backend for initialization, verification and webhooks.

Business: Usman Prime Enterprise — Potiskum, Yobe State — 07067405625 — umohammedatom3@gmail.com
