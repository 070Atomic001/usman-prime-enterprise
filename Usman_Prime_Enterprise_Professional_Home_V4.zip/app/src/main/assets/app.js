const services=[
  ["💻","IT Services","Computer setup, software, troubleshooting and technical support."],
  ["🎨","Design Services","Logos, flyers, branding and digital graphics."],
  ["📄","Document Services","Typing, formatting, printing support and document preparation."],
  ["📱","Airtime & Data","Convenient airtime and data support for your everyday needs."],
  ["🛍️","Marketplace","Digital marketplace support and selected products/services."],
  ["📢","Advertisements","Promotional designs and digital advertising support."]
];
const grid=document.querySelector('#servicesGrid');
const select=document.querySelector('#service');
const order=document.querySelector('#order');
services.forEach(([icon,name,desc])=>{
  const card=document.createElement('button');
  card.type='button'; card.className='card';
  card.innerHTML=`<div class="icon">${icon}</div><h3>${name}</h3><p>${desc}</p>`;
  card.addEventListener('click',()=>{select.value=name;order.scrollIntoView({behavior:'smooth',block:'start'});setTimeout(()=>document.querySelector('#details').focus(),450)});
  grid.appendChild(card);
  const option=document.createElement('option'); option.value=name; option.textContent=name; select.appendChild(option);
});
document.querySelector('#orderForm').addEventListener('submit',e=>{
  e.preventDefault();
  const name=document.querySelector('#name').value.trim();
  const phone=document.querySelector('#phone').value.trim();
  const service=select.value;
  const amount=document.querySelector('#amount').value.trim()||'Not specified';
  const details=document.querySelector('#details').value.trim()||'No additional details';
  const text=`Hello Usman Prime Enterprise, I would like to request a service.%0A%0AName: ${encodeURIComponent(name)}%0APhone: ${encodeURIComponent(phone)}%0AService: ${encodeURIComponent(service)}%0ABudget: ${encodeURIComponent(amount)}%0ADetails: ${encodeURIComponent(details)}`;
  document.querySelector('#status').innerHTML=`Request ready. <a href="https://wa.me/2347067405625?text=${text}">Tap here to send it on WhatsApp →</a>`;
});
