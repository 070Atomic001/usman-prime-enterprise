# Usman Prime Enterprise — Android V4

Professional Android app source for Usman Prime Enterprise.

Business: Potiskum, Yobe State — 07067405625 — umohammedatom3@gmail.com

## Build

The included GitHub Actions workflow automatically finds the newest `.zip` uploaded to the repository root. It no longer depends on an exact ZIP filename, so filenames such as `(1).zip` will not break extraction.

The workflow builds `app-debug.apk` and uploads it as the `usman-prime-enterprise-apk` artifact.
