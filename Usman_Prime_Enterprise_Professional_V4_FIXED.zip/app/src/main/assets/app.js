const services=[
  ["💻","IT Services"],["🎨","Design Services"],["📄","Document Services"],
  ["📱","Airtime & Data"],["🛍️","Marketplace"],["📢","Advertisements"]
];

const g=document.querySelector("#services");
const s=document.querySelector("#service");
const order=document.querySelector("#order");

services.forEach(([icon,name])=>{
  const card=document.createElement("button");
  card.type="button";
  card.className="card";
  card.innerHTML=`<div>${icon}</div><h3>${name}</h3><p>Professional ${name.toLowerCase()}.</p>`;
  card.addEventListener("click",()=>{
    s.value=name;
    order.scrollIntoView({behavior:"smooth",block:"start"});
    document.querySelector("#details").focus();
  });
  g.appendChild(card);
  const option=document.createElement("option");
  option.value=name;
  option.textContent=name;
  s.appendChild(option);
});

document.querySelector("#orderForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=document.querySelector("#name").value.trim();
  const phone=document.querySelector("#phone").value.trim();
  const service=s.value;
  const details=document.querySelector("#details").value.trim();
  const budget=document.querySelector("#budget").value;
  const message=`New Usman Prime Enterprise Order%0A%0AName: ${encodeURIComponent(name)}%0APhone: ${encodeURIComponent(phone)}%0AService: ${encodeURIComponent(service)}%0ABudget: ${encodeURIComponent(budget||"Not specified")}%0ADetails: ${encodeURIComponent(details)}`;
  document.querySelector("#status").innerHTML=`Order prepared successfully. <a href="https://wa.me/2347067405625?text=${message}">Tap here to send the order on WhatsApp.</a>`;
});

document.querySelector("#reset")?.addEventListener("click",()=>location.reload());
