package com.usmanprime.enterprise;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int GOLD = Color.rgb(201, 162, 39);
    private static final int DARK = Color.rgb(17, 17, 17);
    private static final int CARD = Color.rgb(30, 30, 30);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(205, 205, 205);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(DARK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(root);

        TextView brand = text("USMAN PRIME ENTERPRISE", 27, GOLD, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, lp(-1, -2, 0));

        TextView subtitle = text("IT SERVICES & DIGITAL SOLUTIONS", 14, MUTED, false);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, lp(-1, -2, 0));

        TextView intro = text(
            "Professional technology solutions for individuals, businesses and organizations.",
            17, WHITE, false);
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(0, dp(24), 0, dp(20));
        root.addView(intro, lp(-1, -2, 0));

        addSection(root, "OUR SERVICES",
            "Website design & development\nMobile app solutions\nIT support & troubleshooting\nDigital business solutions\nBranding & professional design");

        addSection(root, "CONTACT",
            "Phone: 07067405625\nEmail: umohammedatom3@gmail.com\nLocation: Potiskum, Yobe State, Nigeria");

        Button call = button("CALL US");
        call.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_DIAL);
            i.setData(Uri.parse("tel:07067405625"));
            startActivity(i);
        });
        root.addView(call, lp(-1, dp(52), dp(12)));

        Button email = button("SEND EMAIL");
        email.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SENDTO);
            i.setData(Uri.parse("mailto:umohammedatom3@gmail.com"));
            startActivity(i);
        });
        root.addView(email, lp(-1, dp(52), dp(12)));

        TextView footer = text("© 2026 Usman Prime Enterprise\nProfessional. Reliable. Digital.",
            13, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, 0);
        root.addView(footer, lp(-1, -2, 0));

        setContentView(scroll);
    }

    private void addSection(LinearLayout root, String title, String body) {
        TextView t = text(title, 16, GOLD, true);
        t.setPadding(dp(18), dp(16), dp(18), dp(8));
        root.addView(t, lp(-1, -2, 0));

        TextView b = text(body, 16, WHITE, false);
        b.setBackgroundColor(CARD);
        b.setPadding(dp(18), dp(16), dp(18), dp(16));
        root.addView(b, lp(-1, -2, 0));
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(DARK);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackgroundColor(GOLD);
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setTypeface(null, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        return v;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, 0, 0, bottom);
        return p;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }
}
