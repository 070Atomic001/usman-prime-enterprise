const services=[
  ["💻","IT Services","Computer setup, software installation, troubleshooting and technical support."],
  ["🎨","Design Services","Professional flyers, branding, graphics and digital designs."],
  ["📄","Document Services","Typing, printing, formatting, scanning and document preparation."],
  ["📱","Airtime & Data","Convenient airtime and data support for your everyday needs."],
  ["🛍️","Marketplace","Products and useful digital services for customers and businesses."],
  ["📢","Advertisements","Business promotion, digital adverts and social media support."]
];
const grid=document.querySelector('#servicesGrid'), select=document.querySelector('#service');
services.forEach(([icon,name,desc])=>{
 const card=document.createElement('button'); card.type='button'; card.className='card';
 card.innerHTML=`<div class="service-icon">${icon}</div><h3>${name}</h3><p>${desc}</p>`;
 card.onclick=()=>{select.value=name;document.querySelector('#request').scrollIntoView({behavior:'smooth'});setTimeout(()=>document.querySelector('#details').focus(),450)};
 grid.appendChild(card);
 const option=document.createElement('option');option.value=name;option.textContent=name;select.appendChild(option);
});

document.querySelector('#orderForm').addEventListener('submit',e=>{
 e.preventDefault();
 const name=document.querySelector('#name').value.trim(),phone=document.querySelector('#phone').value.trim(),service=select.value,amount=document.querySelector('#amount').value.trim(),details=document.querySelector('#details').value.trim();
 const text=`Hello Usman Prime Enterprise,%0A%0AI would like to request a service.%0A%0AName: ${encodeURIComponent(name)}%0APhone: ${encodeURIComponent(phone)}%0AService: ${encodeURIComponent(service)}%0ABudget: ${encodeURIComponent(amount?`₦${amount}`:'Not specified')}%0ADetails: ${encodeURIComponent(details||'Not provided')}`;
 document.querySelector('#status').innerHTML=`Opening WhatsApp… <a href="https://wa.me/2347067405625?text=${text}" target="_blank">Tap here if it does not open.</a>`;
 window.open(`https://wa.me/2347067405625?text=${text}`,'_blank');
});
